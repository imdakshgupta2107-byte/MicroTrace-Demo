import {defineConfig} from 'vitest/config';
import path from 'node:path';
export default defineConfig({resolve:{alias:{'@':path.resolve(import.meta.dirname,'src')}},test:{environment:'node',include:['tests/automation/**/*.test.ts'],maxWorkers:1,testTimeout:30_000,hookTimeout:90_000,restoreMocks:true}});
